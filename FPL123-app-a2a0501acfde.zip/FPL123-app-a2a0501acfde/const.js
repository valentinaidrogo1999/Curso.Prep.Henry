const direccionGlobal = __dirname + "/public/";

module.exports = {
  direccionGlobal,
};
