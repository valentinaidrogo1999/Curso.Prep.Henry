const { BrowserWindow } = require("electron");
const { direccionGlobal } = require("../../const");
let nuevaVentana = null;
const ventanaCuenta = () => {
  if (getVentanaCuenta() === null) {
    nuevaVentana = new BrowserWindow({
      width: 350,
      height: 600,
      frame: true,
      webPreferences: {
        contextIsolation: false,
        nodeIntegration: true,
        nodeIntegrationInWorker: true,
        enableRemoteModule: true,
      },
    });
    nuevaVentana.loadURL(direccionGlobal + "/page/cuenta.html");
    nuevaVentana.show();
  }
};
function getVentanaCuenta() {
  return nuevaVentana;
}
module.exports = {
  ventanaCuenta,
  getVentanaCuenta,
};
