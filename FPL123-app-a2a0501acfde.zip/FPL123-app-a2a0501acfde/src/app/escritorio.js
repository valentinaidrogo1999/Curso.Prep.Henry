const { BrowserWindow } = require("electron");
const { direccionGlobal } = require("../../const");
let nuevaVentana = null;
const ventanaEscritorio = () => {
  if (getventanaEscritorio() === null) {
    nuevaVentana = new BrowserWindow({
      width: 1000,
      height: 500,
      frame: false,
      webPreferences: {
        contextIsolation: false,
        nodeIntegration: true,
        nodeIntegrationInWorker: true,
        enableRemoteModule: true,
      },
    });
    nuevaVentana.loadURL(direccionGlobal + "/page/escritorio.html");
    nuevaVentana.show();
  }
};
function getventanaEscritorio() {
  return nuevaVentana;
}
module.exports = {
  ventanaEscritorio,
  getventanaEscritorio,
};
