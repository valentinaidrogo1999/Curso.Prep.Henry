const { BrowserWindow } = require("electron");
const { direccionGlobal } = require("../../const");
let ventanaPrincipal;
function crearVentana() {
  ventanaPrincipal = new BrowserWindow({
    width: 350,
    height: 600,
    center: true,
    frame: false,
    webPreferences: {
      contextIsolation: false,
      nodeIntegration: true,
      nodeIntegrationInWorker: true,
      enableRemoteModule: true,
    },
  });

  const direccionIndexVenta = direccionGlobal + "index.html";
  ventanaPrincipal.loadURL(direccionIndexVenta);
}
module.exports = {
  crearVentana,
};
