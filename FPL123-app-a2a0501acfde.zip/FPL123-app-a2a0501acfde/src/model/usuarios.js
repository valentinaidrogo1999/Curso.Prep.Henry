const { db } = require("../sql/db");
const sequelize = require("sequelize");
const { personasModelo } = require("./personas");

const usuariosModelo = db.define(
  "usuarios",
  {
    pkUsuario: {
      type: sequelize.NUMBER,
      primaryKey: true,
      autoIncrement: true,
    },
    correo: {
      type: sequelize.STRING,
    },
    contrasenia: {
      type: sequelize.STRING,
    },
    fkPersona: {
      type: sequelize.STRING,
    },
  },
  {
    timestamps: false,
  }
);
personasModelo.hasMany(usuariosModelo, {
  foreignKey: "fkPersona",
  sourceKey: "pkPersona",
});
usuariosModelo.belongsTo(personasModelo, { foreignKey: "fkPersona" });

const crear = async (correo, contrasenia, fkPersona) => {
  let datosUsuario = {};
  const respuesta = await usuariosModelo.create({
    correo: correo,
    contrasenia: contrasenia,
    fkPersona: fkPersona,
  });
  if (respuesta != null) {
    datosUsuario.pkUsuario = respuesta.getDataValue("pkUsuario");
    datosUsuario.correo = respuesta.getDataValue("correo");
    datosUsuario.contrasenia = respuesta.getDataValue("contrasenia");
    datosUsuario.fkPersona = respuesta.getDataValue("fkPersona");
  }
  return datosUsuario;
};

const buscarByContraseniaAndCorreo = async (correoAuth, contraseniaAuth) => {
  let datosUsuario = {};
  const respuesta = await usuariosModelo.findOne({
    where: {
      [sequelize.Op.and]: {
        correo: correoAuth,
        contrasenia: contraseniaAuth,
      },
    },
    include: [
      {
        model: personasModelo,
      },
    ],
  });
  if (respuesta != null) {
    datosUsuario.pkUsuario = respuesta.getDataValue("pkUsuario");
    datosUsuario.correo = respuesta.getDataValue("correo");
    datosUsuario.contrasenia = respuesta.getDataValue("contrasenia");
    datosUsuario.nombre = respuesta.getDataValue("nombres");
    return datosUsuario;
  }
  return datosUsuario;
};

module.exports = {
  usuariosModelo,
  crear,
  buscarByContraseniaAndCorreo,
};
