const { db } = require("../sql/db");
const sequelize = require("sequelize");

const personasModelo = db.define(
  "personas",
  {
    pkPersona: {
      type: sequelize.NUMBER,
      primaryKey: true,
      autoIncrement: true,
    },
    nombres: {
      type: sequelize.STRING,
    },
    apellidos: {
      type: sequelize.STRING,
    },
  },
  {
    timestamps: false,
  }
);

const crear = async (nombre, apellido) => {
  let datosPersona = {};
  const respuesta = await personasModelo.create({
    nombres: nombre,
    apellidos: apellido,
  });
  if (respuesta != null) {
    datosPersona.pk = respuesta.getDataValue("pkPersona");
    datosPersona.nombre = respuesta.getDataValue("nombres");
    datosPersona.apellido = respuesta.getDataValue("apellidos");
    return datosPersona;
  }
  return datosPersona;
};

module.exports = {
  personasModelo,
  crear,
};
