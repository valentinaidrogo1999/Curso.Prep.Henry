const { BrowserWindow } = require("electron");
const { direccionGlobal } = require("../../const");
let mensaje = "";
let titulo = "";
let botonesAceptar = false;
const segundoActivo = 1500;
let nuevaVentana = null;
function alertaNotificacion(mensajes, boton) {
  mensaje = mensajes;
  titulo = "¡Notificación!";
  if (boton != null || boton != undefined) {
    botonesAceptar = boton;
  }
  abrirVentana();
}

function alertaError(mensajes, boton) {
  mensaje = mensajes;
  titulo = "¡Advertencia!";
  if (boton != null || boton != undefined) {
    botonesAceptar = boton;
  }
  abrirVentana();
}

function getMensaje() {
  return mensaje;
}
function getTitulo() {
  return titulo;
}
function getTiempoActivo() {
  return segundoActivo;
}
function getbotonesAceptar() {
  return botonesAceptar;
}
function abrirVentana() {
  if (getNuevaVentana() === null) {
    nuevaVentana = new BrowserWindow({
      width: 600,
      height: 250,
      frame: false,
      webPreferences: {
        contextIsolation: false,
        nodeIntegration: true,
        nodeIntegrationInWorker: true,
        enableRemoteModule: true,
      },
    });
    nuevaVentana.loadURL(direccionGlobal + "/layout/alertas.html");
    nuevaVentana.show();
  }
}

function reiniciarVentana() {
  nuevaVentana = null;
}

function getNuevaVentana() {
  return nuevaVentana;
}

module.exports = {
  alertaNotificacion,
  getTitulo,
  getMensaje,
  getTiempoActivo,
  getbotonesAceptar,
  reiniciarVentana,
  alertaError,
};
