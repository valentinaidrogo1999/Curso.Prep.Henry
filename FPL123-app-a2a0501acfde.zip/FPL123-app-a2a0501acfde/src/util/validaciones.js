const { alertaError } = require("./Alertas");
let contrasenia = "";
function camposVacios(textoCampos) {
  const numeroTotalIteraciones = textoCampos.length / 2;
  let campos = "";
  for (let index = 0; index < numeroTotalIteraciones; index++) {
    const nombreCampo = textoCampos[index * 2];
    const textoCampo = textoCampos[index * 2 + 1];
    if (textoCampo === "" || textoCampo === undefined || textoCampo === null) {
      campos += nombreCampo + ",";
    }
  }
  if (campos != "") {
    return "Estos campos hacen falta rellenar: " + campos;
  }
  return campos;
}

const longitudCampo = (texto, longitudMimina, longintudMaxima) => {
  let mensaje = {};
  mensaje.texto = texto;
  if (texto === undefined) {
    mensaje.mensaje = "texto no definido";
    alertaError(mensaje.mensaje, true);
    return mensaje;
  }
  if (longitudMimina === undefined) {
    mensaje.mensaje = "Longitud Minima no definida";
    alertaError(mensaje.mensaje, true);
    return mensaje;
  }
  if (longintudMaxima === undefined) {
    mensaje.mensaje = "Longitud Maxima no definida";
    alertaError(mensaje.mensaje, true);
    return mensaje;
  }
  const logintudTexto = texto.length;
  if (logintudTexto < longitudMimina) {
    return (mensaje.mensaje =
      "Debes de tener un minimo de " + longitudMimina + "caracteres.");
  }
  if (logintudTexto > longintudMaxima) {
    mensaje.texto = texto.substr(0, longintudMaxima);
  }
  mensaje.texto;
  return mensaje;
};

const contrasenias = (texto, primeraVes) => {
  let mensaje = {};
  if (primeraVes) {
    contrasenia = texto;
  }
  if (texto != "") {
    //const expresion = /[a-zA-Z0-9]{2}[&$%+-_.,:;][^*/@""''()][^\t\r\n\f]\b/gi;
    const expresion = /(?=.*[a-z])(?=.*[A-Z]).*$/gi;
    if (!expresion.test(texto)) {
      mensaje.mensaje = "La contraseña no es apropiada";
      mensaje.texto = texto;
      return mensaje;
    }
    return mensaje;
  }
  alertaError("No se encontro texto en contraseña", true);
};

const confirmacionContrasenia = texto => {
  const contraseniaConfirmada = texto;
  const mensajeValidacionContrasenia = contrasenias(
    contraseniaConfirmada,
    false
  );
  let mensaje = "";
  if (mensajeValidacionContrasenia === "") {
    if (contrasenia != contraseniaConfirmada) {
      mensaje.mensaje = "";
    }
  }
  return mensajeValidacionContrasenia;
};
module.exports = {
  camposVacios,
  longitudCampo,
  contrasenias,
  confirmacionContrasenia,
};
