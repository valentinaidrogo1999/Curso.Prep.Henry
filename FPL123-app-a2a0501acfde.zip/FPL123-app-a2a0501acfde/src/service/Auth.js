const personasModelo = require("../model/personas");
const usuarioModelo = require("../model/usuarios");
const Alertas = require("../util/Alertas");
const Cuenta = require("../app/cuenta");
const Escritorio = require("../app/escritorio");

let correoAuth = "";
let nombreAuth = "";
let contraseniaAuth = "";
let pkUsuarioAuth = 0;

const crearCuenta = async jsonCuenta => {
  const { nombre, apellido, correo, contrasenia } = jsonCuenta;
  const sqlPersona = await personasModelo.crear(nombre, apellido);
  const pkPersona = sqlPersona.pk;
  if (pkPersona != undefined || pkPersona != null) {
    const sqlUsuario = await usuarioModelo.crear(
      correo,
      contrasenia,
      pkPersona
    );
    const pkUsuario = sqlUsuario.pkUsuario;
    if (pkUsuario != null || pkUsuario != undefined) {
      correoAuth = sqlUsuario.correo;
      nombreAuth = sqlPersona.nombre;
      contraseniaAuth = sqlUsuario.contrasenia;
      pkUsuarioAuth = sqlUsuario.pkUsuario;
    } else {
      "Ops!, ocurrio un error".alertaNotificacion();
    }
  } else {
    "Ops!, ocurrio un error".alertaNotificacion();
  }
};

const accesoApp = async (correo, contrasenia) => {
  const sqlUsuario = await usuarioModelo.buscarByContraseniaAndCorreo(
    correo,
    contrasenia
  );
  if (sqlUsuario.pkUsuario != null || sqlUsuario.pkUsuario != undefined) {
    correoAuth = sqlUsuario.correo;
    nombreAuth = sqlUsuario.nombre;
    contraseniaAuth = sqlUsuario.contrasenia;
    pkUsuarioAuth = sqlUsuario.pkUsuario;
    Escritorio.ventanaEscritorio();
    return true;
  } else {
    Alertas.alertaNotificacion(
      "Tu usuario y/o contraseña estan mal escritos, vuelve a intentar",
      true
    );
    return false;
  }
};

function getCorreo() {
  return correoAuth;
}
module.exports = {
  crearCuenta,
  getCorreo,
  accesoApp,
};
