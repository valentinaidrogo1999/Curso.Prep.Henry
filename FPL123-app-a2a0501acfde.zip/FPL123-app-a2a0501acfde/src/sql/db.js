const { Sequelize } = require("sequelize");

const db = new Sequelize("controlTiempo", "fili", "%codeATHome2021!%$", {
  host: "appscodeathome.ovh",
  port: 3306,
  dialect: "mysql",
});

module.exports = {
  db,
};
