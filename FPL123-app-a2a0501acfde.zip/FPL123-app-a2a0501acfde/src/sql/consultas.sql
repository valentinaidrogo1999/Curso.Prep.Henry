create database controlTiempo;
use controlTiempo;
select * from personas;
truncate personas;
create table personas(
	pkPersona int not null primary key auto_increment,
    nombres varchar(25),
    apellidos varchar(25)
);
select * from usuarios;
#drop table usuarios;
#truncate usuarios;
create table usuarios(
	pkUsuario int not null primary key auto_increment,
    correo text,
    contrasenia text,
    fkPersona int
);

create table equipos(
	pkEquipo int not null primary key auto_increment,
    nombreEquipo varchar(35),
    codigoEquipo varchar(7),
    acronimoEquipo varchar(4),
    fkUsuario int not null
);

create table integrantesEquipo(
	pkIntegranteEquipo int not null primary key auto_increment,
    fkUsuario int not null,
    fkEquipo int not null
);

