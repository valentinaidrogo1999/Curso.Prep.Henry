const templeteNavbar = nombreVentana => {
  let nuevoNombre = "";
  if (nombreVentana === undefined || nombreVentana === null) {
    nuevoNombre = "Control de Actividades";
  } else {
    nuevoNombre = nombreVentana;
  }

  return `
    <div class="col-sm-12 bg-primary-dark d-flex justify-content-between p-2">
    <span class="bold text-white mt-2" >${nuevoNombre}</span>
    <div>
    <button onclick="recargarApp()" class="btn btn-primary"><i class="fas fa-spinner"></i></button>
    <button onclick="minimizarApp()" class="btn btn-primary"><i class="fas fa-grip-lines"></i></button>
    <button onclick="cerrarApp()" class="btn btn-primary"><i class="fas fa-window-close"></i></button>
    </div>
    </div>`;
};

const rendizarNavbar = nombreVentana => {
  document.getElementById("navbar-opciones").innerHTML =
    templeteNavbar(nombreVentana);
};

const cerrarApp = () => {
  window.close();
};

const recargarApp = () => {
  location.reload();
};

const minimizarApp = () => {
  window.blur();
};
