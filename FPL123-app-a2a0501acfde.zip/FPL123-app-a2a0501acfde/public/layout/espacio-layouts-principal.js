const indentificadorRenderizado = "espacio-layouts-principal";
const plantillaLayoutPrincipal = datos => {
  let plantilla = "";
  if (datos.length === 0 || datos === null || datos === undefined) {
    plantilla = sugerenciasPrincipal();
  } else {
    plantilla = plantillaCompanieros() + "" + plantillaActividades();
  }
  document.getElementById(indentificadorRenderizado).innerHTML = plantilla;
};

function sugerenciasPrincipal() {
  return `
    <button class="btn btn-secondary form-max my-2" onclick="NuevaLibreta()">
        Nueva Libreta
    </button>
    <button class="btn btn-secondary form-max my-2" onclick="NuevoEquipo()">
        Nuevo Equipo
    </button>
    <button class="btn btn-secondary form-max my-2" onclick="NuevoContacto()">
        Nuevo Contacto
    </button>
  `;
}

function plantillaCompanieros() {}

function plantillaActividades() {}
