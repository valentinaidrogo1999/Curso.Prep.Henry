const PrincipalActividades = () => {
  return `<div class="col-sm-12">
    <span class="text-muted bold">Activades</span>
    <button class="btn btn-success">Nueva Actividad</button>
    </div>`;
};

const todasActividades = (orden, fechas, tiposActidades) => {};

const platillaActidades = actividades => {
  if (
    actividades.length === 0 ||
    actividades === undefined ||
    actividades === null
  ) {
  }
};
