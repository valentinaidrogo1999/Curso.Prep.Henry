const { remote } = require("electron");
const Alertas = remote.require("./src/util/Alertas.js");
let identificadorBarra = "";
function initBarraPorgreso() {}

const templeteBarraProgreso = idBarra => {
  identificadorBarra = idBarra;
  validacionIdentificacion();
  return `
    <div class="col-sm-12 spiner-line px-0 my-1">
        <div id="${idBarra}" class="py-1"></div>
    </div>
  `;
};

function agregarMasWidth(cantidad) {
  validacionIdentificacion();
  document.getElementById(identificadorBarra).style.width = cantidad + "%";
}

function fondoColor(color) {
  validacionIdentificacion();
  document.getElementById(identificadorBarra).style.backgroundColor = color;
}

function validacionIdentificacion() {
  if (identificadorBarra === "") {
    Alertas.alertaError(
      "El identificador la barra de progreso no esta definida"
    );
    return;
  }
}
