const { remote } = require("electron");
const cuenta = remote.require("./src/app/cuenta.js");
const validaciones = remote.require("./src/util/validaciones.js");
const Auth = remote.require("./src/service/Auth.js");
const Alerta = remote.require("./src/util/Alertas.js");
rendizarNavbar();
document.getElementById("crear-cuenta").addEventListener("click", () => {
  cerrarApp();
  cuenta.ventanaCuenta();
});

document.getElementById("acceso-app").addEventListener("click", async () => {
  const usuario = document.getElementById("usuario").value;
  const contrasenia = document.getElementById("contrasenia").value;
  const constructorValidaciones = [
    "Usuario",
    usuario,
    "contraseña",
    contrasenia,
  ];

  const validacion = validaciones.camposVacios(constructorValidaciones);
  if (validacion === "") {
    if (await Auth.accesoApp(usuario, contrasenia)) {
      cerrarApp();
    }
  } else {
    Alerta.alertaNotificacion(validacion, true);
  }
});
