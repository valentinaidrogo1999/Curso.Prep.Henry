rendizarNavbar("Principal");
plantillaLayoutPrincipal([]);
