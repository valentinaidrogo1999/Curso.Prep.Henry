const { remote } = require("electron");
const alert = remote.require("./src/util/Alertas.js");
const temepleteAlert = () => {
  const plantilla = `
  <div class="col-sm-12 text-center text-white py-2 bg-primary-dark" id="titulo-alerta">
    ${alert.getTitulo()}
  </div>
  <div class="col-sm-12 p-3 text-white" id="mensaje-alerta">
    ${alert.getMensaje()}
  </div> 
  ${plantillaBotones(alert.getbotonesAceptar())}
  `;
  document.getElementById("ventana-alerta").innerHTML = plantilla;
};

const plantillaBotones = botones => {
  return botones
    ? `
  <div class="col-sm-12 mt-4 d-flex justify-content-center" id="mensaje-alerta">
    <button class="btn btn-secondary" onclick="cerrarAlerta()" >Aceptar</button>
  </div>
  `
    : "";
};

function cerrarAlerta() {
  if (!alert.getbotonesAceptar()) {
    setTimeout(() => {
      window.close();
      alert.reiniciarVentana();
    }, alert.getTiempoActivo());
  }
  alert.reiniciarVentana();
  window.close();
}
function initPlantilla() {
  temepleteAlert();
  if (!alert.getbotonesAceptar()) {
    cerrarAlerta();
  }
}

initPlantilla();
