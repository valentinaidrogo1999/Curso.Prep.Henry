const { remote } = require("electron");
const login = remote.require("./src/app/index.js");
const auth = remote.require("./src/service/Auth.js");
const validaciones = remote.require("./src/util/validaciones.js");
const alertas = remote.require("./src/util/Alertas.js");
rendizarNavbar("Crear Cuenta");

document.getElementById("regrear-ventana").addEventListener("click", () => {
  cerrarApp();
  login.crearVentana();
});

document.getElementById("crear-cuenta").addEventListener("click", async () => {
  const nombre = document.getElementById("nombre").value;
  const apellido = document.getElementById("apellido").value;
  const correo = document.getElementById("correo").value;
  const contrasenia = document.getElementById("contrasenia").value;
  const ConfirmarContrasenia = document.getElementById(
    "confirmarContrasenia"
  ).value;
  const contrunctorValidacionesVacios = [
    "Nombre",
    nombre,
    "Apellidos",
    apellido,
    "Correo",
    correo,
    "Contraseña",
    contrasenia,
    "Confirmar Contrasenia",
    ConfirmarContrasenia,
  ];
  validaciones.contrasenias(contrasenia);
  return;
  const mensajeValidacion = validaciones.camposVacios(
    contrunctorValidacionesVacios
  );

  if (mensajeValidacion === "") {
    const jsonCuenta = {
      nombre: nombre,
      apellido: apellido,
      correo: correo,
      contrasenia: ConfirmarContrasenia,
    };
    document.getElementById("crear-cuenta").style.display = "none";
    document.getElementById("regrear-ventana").style.display = "none";
    document.getElementById("cargar-cuenta").style.display = "block";
    await auth.crearCuenta(jsonCuenta);
    limpiarCampos();
  } else {
    alertas.alertaNotificacion(mensajeValidacion, true);
  }
});

function limpiarCampos() {
  nombre.value = "";
  apellido.value = "";
  correo.value = "";
  contrasenia.value = "";
  confirmarContrasenia.value = "";
}

function initVentanta() {
  document.getElementById("cargar-cuenta").style.display = "none";
}

function longitud(event, logintudTexto) {
  const texto = event.target.value;
  if (texto != "") {
    event.target.value = validaciones.longitudCampo(
      texto,
      0,
      logintudTexto
    ).texto;
  }
}

initVentanta();
