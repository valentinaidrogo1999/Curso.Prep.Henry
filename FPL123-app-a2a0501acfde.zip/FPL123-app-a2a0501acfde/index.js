const { app } = require("electron");
const { crearVentana } = require("./src/app/index");
const { db } = require("./src/sql/db");
app.on("ready", () => {
  try {
    db.authenticate();
  } catch (error) {}
  crearVentana();
});
